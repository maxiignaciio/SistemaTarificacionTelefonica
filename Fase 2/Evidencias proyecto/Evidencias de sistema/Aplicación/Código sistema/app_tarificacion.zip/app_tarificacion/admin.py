from django.contrib import admin
# from .models import Proveedor, CustomUser, CodUnidad, CtaPresu, Anexo

# Register your models here.

# admin.site.register(Proveedor)
# admin.site.register(CustomUser)
# admin.site.register(CodUnidad)
# admin.site.register(CtaPresu)
# admin.site.register(Anexo)